package br.pucrs.engswii.beans;

public class Subject {

    int cod;
    String descricao;
    int cod_turma;
    
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public int getCodTurma() {
		return cod_turma;
	}
	public void setCodTurma(int cod_turma) {
		this.cod_turma = cod_turma;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
