# Enunciado da Atividade
1. Clone o repositório

2. Abra o projeto, que é implementado em Java com Spring Boot e Maven

3. Responda às questões abaixo:
    3-1. Quais são os endpoint implementados?

        @DeleteMapping("/delete/student/{regdNum}")
        @PostMapping("/register/student")
        @GetMapping("/student/allstudent")
        @PutMapping("/update/student")

    3-2. Quais são as entradas destes endpoints (tipos e formatos)?

        @DeleteMapping("/delete/student/{regdNum}") -> path variable do tipo string
        @PostMapping("/register/student") -> requestbody do tipo student
        @GetMapping("/student/allstudent") -> não tem
        @PutMapping("/update/student") -> requestbody do tipo student
    
    3-3. Quais são as saídas?

        @DeleteMapping("/delete/student/{regdNum}") -> uma mensagem informando se o estudante foi deletado com sucesso ou não
        @PostMapping("/register/student") -> retorna uma instancia da classe StudentRegistrationReply com o novo aluno registrado
        @GetMapping("/student/allstudent") -> retorna uma lista com todos os estudantes
        @PutMapping("/update/student") -> retorna uma mensagem informando se as informações do estudante foram atualizadas com sucesso ou não

    3-4. Testem cada endpoint.

4. Implemente uma funcionalidade simples de gestão de disciplinas:
    4-1. criação de disciplinas
    4-2. Código da disciplina, descrição e código da turma
    4-3. não permitir disciplinas com código duplicado
    4-4. listar todas as disciplinas criadas
